// Custom JavaScript for Personal Portfolio
import bootstrap from "bootstrap"

document.addEventListener("DOMContentLoaded", () => {
  // Smooth scrolling for navigation links
  const navLinks = document.querySelectorAll('.nav-link[href^="#"]')
  navLinks.forEach((link) => {
    link.addEventListener("click", function (e) {
      e.preventDefault()
      const targetId = this.getAttribute("href")
      const targetSection = document.querySelector(targetId)

      if (targetSection) {
        const offsetTop = targetSection.offsetTop - 70 // Account for fixed navbar
        window.scrollTo({
          top: offsetTop,
          behavior: "smooth",
        })
      }

      // Close mobile menu if open
      const navbarCollapse = document.querySelector(".navbar-collapse")
      if (navbarCollapse.classList.contains("show")) {
        const bsCollapse = new bootstrap.Collapse(navbarCollapse)
        bsCollapse.hide()
      }
    })
  })

  // Active navigation highlighting
  window.addEventListener("scroll", () => {
    const sections = document.querySelectorAll("section[id]")
    const navLinks = document.querySelectorAll('.nav-link[href^="#"]')

    let current = ""
    sections.forEach((section) => {
      const sectionTop = section.offsetTop - 100
      const sectionHeight = section.clientHeight

      if (window.pageYOffset >= sectionTop && window.pageYOffset < sectionTop + sectionHeight) {
        current = section.getAttribute("id")
      }
    })

    navLinks.forEach((link) => {
      link.classList.remove("active")
      if (link.getAttribute("href") === `#${current}`) {
        link.classList.add("active")
      }
    })
  })

  // Navbar background on scroll
  window.addEventListener("scroll", () => {
    const navbar = document.querySelector(".navbar")
    if (window.scrollY > 50) {
      navbar.style.backgroundColor = "rgba(0, 0, 0, 0.98)"
    } else {
      navbar.style.backgroundColor = "rgba(0, 0, 0, 0.95)"
    }
  })

  // Portfolio "See More" functionality
  const seeMoreBtn = document.getElementById("seeMoreBtn")
  const hiddenProjects = document.querySelectorAll(".hidden-project")
  let projectsVisible = false

  seeMoreBtn.addEventListener("click", function () {
    if (!projectsVisible) {
      // Show hidden projects
      hiddenProjects.forEach((project, index) => {
        setTimeout(() => {
          project.style.display = "block"
          setTimeout(() => {
            project.classList.add("show")
          }, 50)
        }, index * 100)
      })

      this.textContent = "See Less"
      projectsVisible = true
    } else {
      // Hide projects
      hiddenProjects.forEach((project, index) => {
        setTimeout(() => {
          project.classList.remove("show")
          setTimeout(() => {
            project.style.display = "none"
          }, 300)
        }, index * 50)
      })

      this.textContent = "See More"
      projectsVisible = false
    }
  })

  // Contact form submission
  const contactForm = document.getElementById("contactForm")
  const confirmationMessage = document.getElementById("confirmationMessage")

  contactForm.addEventListener("submit", (e) => {
    e.preventDefault()

    // Get form data
    const name = document.getElementById("name").value
    const email = document.getElementById("email").value
    const message = document.getElementById("message").value

    // Simple validation
    if (name && email && message) {
      // Show confirmation message
      confirmationMessage.style.display = "block"

      // Reset form
      contactForm.reset()

      // Hide confirmation message after 5 seconds
      setTimeout(() => {
        confirmationMessage.style.display = "none"
      }, 5000)

      // Scroll to confirmation message
      confirmationMessage.scrollIntoView({ behavior: "smooth", block: "center" })
    }
  })

  // Tab functionality for About section (custom implementation)
  const tabButtons = document.querySelectorAll("#aboutTabs .nav-link")
  const tabPanes = document.querySelectorAll(".tab-pane")

  tabButtons.forEach((button) => {
    button.addEventListener("click", function (e) {
      e.preventDefault()

      // Remove active class from all buttons and panes
      tabButtons.forEach((btn) => btn.classList.remove("active"))
      tabPanes.forEach((pane) => {
        pane.classList.remove("show", "active")
      })

      // Add active class to clicked button
      this.classList.add("active")

      // Show corresponding tab pane
      const targetPane = document.querySelector(this.getAttribute("data-bs-target"))
      if (targetPane) {
        targetPane.classList.add("show", "active")
      }
    })
  })

  // Animate elements on scroll
  const observerOptions = {
    threshold: 0.1,
    rootMargin: "0px 0px -50px 0px",
  }

  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = "1"
        entry.target.style.transform = "translateY(0)"
      }
    })
  }, observerOptions)

  // Observe portfolio cards and other elements
  const animateElements = document.querySelectorAll(".portfolio-card, .contact-info, .about-image")
  animateElements.forEach((el) => {
    el.style.opacity = "0"
    el.style.transform = "translateY(30px)"
    el.style.transition = "opacity 0.6s ease, transform 0.6s ease"
    observer.observe(el)
  })

  // Add hover effects to portfolio cards
  const portfolioCards = document.querySelectorAll(".portfolio-card")
  portfolioCards.forEach((card) => {
    card.addEventListener("mouseenter", function () {
      this.style.transform = "translateY(-10px) scale(1.02)"
    })

    card.addEventListener("mouseleave", function () {
      this.style.transform = "translateY(0) scale(1)"
    })
  })

  // Typing effect for hero section (optional enhancement)
  const heroTitle = document.querySelector(".hero-content h1")
  if (heroTitle) {
    const text = heroTitle.innerHTML
    heroTitle.innerHTML = ""
    let i = 0

    function typeWriter() {
      if (i < text.length) {
        heroTitle.innerHTML += text.charAt(i)
        i++
        setTimeout(typeWriter, 100)
      }
    }

    // Start typing effect after a short delay
    setTimeout(typeWriter, 1000)
  }
})

// Add some interactive hover effects
document.addEventListener("mousemove", (e) => {
  const cursor = document.querySelector(".cursor")
  if (cursor) {
    cursor.style.left = e.clientX + "px"
    cursor.style.top = e.clientY + "px"
  }
})

// Parallax effect for hero section
window.addEventListener("scroll", () => {
  const scrolled = window.pageYOffset
  const heroSection = document.querySelector(".hero-section")

  if (heroSection) {
    const rate = scrolled * -0.5
    heroSection.style.transform = `translateY(${rate}px)`
  }
})
